package ambiguous.pkg2;

public class Foo {
	public static String pkg ="pkg2";
}
