ant
ant junit-tests-all 2>&1 | sed -e 's/, Time.*//'> testvFOO
diff -u testv2 testvFOO | cdiff
